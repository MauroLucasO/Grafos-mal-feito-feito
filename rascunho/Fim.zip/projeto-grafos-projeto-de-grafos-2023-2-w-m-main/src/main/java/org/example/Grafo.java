package org.example;

import java.io.*;
import java.util.*;

public class Grafo {

    private Map<String, Vertice> nomevertice;
    private int[][] matrizadj;
    int quantidadevertice;
    boolean orientado;
    ArrayList<Vertice> listaVertice;
    private ArrayList<Aresta> listaAresta;

    public Grafo(boolean orientado) {
        this.orientado = orientado;
        this.quantidadevertice = 0;
        this.listaAresta = new ArrayList<>();
        this.listaVertice = new ArrayList<>();
        this.nomevertice = new HashMap<>();
    }

    private void atualizamatriz(Aresta aresta) {

        this.matrizadj[this.nomevertice.get(aresta.getVertice_entrada()).getindice()]
                [this.nomevertice.get(aresta.getVertice_saida()).getindice()] += 1;
        if (!orientado) {
            this.matrizadj[this.nomevertice.get(aresta.getVertice_saida()).getindice()]
                    [this.nomevertice.get(aresta.getVertice_entrada()).getindice()] += 1;
        }
    }

    public void iniciamatriz() {
        this.matrizadj = new int[quantidadevertice][quantidadevertice];
        for (int i = 0; i < quantidadevertice; i++) {
            for (int j = 0; j < quantidadevertice; j++) {
                this.matrizadj[i][j] = 0;
            }
        }
    }

    public int[][] mostraMatriz() {
        this.iniciamatriz();
        int i = 0;
        for (Vertice v : nomevertice.values()) {
            v.setindice(i);
            i++;

        }
        ;
        for (Aresta a : listaAresta) {
            this.atualizamatriz(a);
        }
        ;
        return this.matrizadj;

    }

    public void addAresta(Aresta a) {
        this.listaAresta.add(a);
        this.nomevertice.get(a.getVertice_entrada()).setGrau();
        this.nomevertice.get(a.getVertice_saida()).setGrau();
    }

    public void addVertice(Vertice v) {

        if (!nomevertice.containsKey(v.getNome())) {
            this.listaVertice.add(v);
            this.nomevertice.put(v.getNome(), v);
            this.quantidadevertice++;
        }
    }
    public void removeVertice(String nomeVertice) {
        if (nomevertice.containsKey(nomeVertice)) {
            Vertice verticeRemover = nomevertice.get(nomeVertice);

            listaAresta.removeIf(a ->
                    a.getVertice_entrada().equals(nomeVertice) || a.getVertice_saida().equals(nomeVertice));

            listaVertice.remove(verticeRemover);
            nomevertice.remove(nomeVertice);
            quantidadevertice--;
        }
    }
    public void removeAresta(String verticeEntrada, String verticeSaida) {
        listaAresta.removeIf(a ->
                a.getVertice_entrada().equals(verticeEntrada) && a.getVertice_saida().equals(verticeSaida));

        if (!orientado) {
            listaAresta.removeIf(a ->
                    a.getVertice_entrada().equals(verticeSaida) && a.getVertice_saida().equals(verticeEntrada));
        }
        nomevertice.get(verticeEntrada).setGrau();
        nomevertice.get(verticeSaida).setGrau();
    }
    public int getOrdem() {
        return quantidadevertice;
    }

    public int getGrauvertice(String vertice) {
        return this.nomevertice.get(vertice).getGrau();
    }

    public List<String> verificasumidouro(){
        ArrayList<String> listaSumidouro = new ArrayList<>();
        mostraMatriz();
        int soma = 0;
        if(orientado) {
            for (int i = 0; i < quantidadevertice; i++) {
                for (int j = 0; j < quantidadevertice; j++) {
                    soma = soma + this.matrizadj[i][j];
                }
                if(soma == 0){
                    listaSumidouro.add(listaVertice.get(i).getNome());
                }
                soma = 0;
            }

        }
        return listaSumidouro;
    }

    public List<String> verificafonte(){
        ArrayList<String> listaFonte = new ArrayList<>();
        mostraMatriz();
        int soma = 0;
        if(orientado) {

            for (int j = 0; j < quantidadevertice; j++) {
                for (int i = 0; i < quantidadevertice; i++) {
                    soma = soma + this.matrizadj[i][j];
                }
                if(soma == 0){
                    listaFonte.add(listaVertice.get(j).getNome());
                }
                soma=0;
            }
        }
        return listaFonte;
    }
    //caminho inverso
    public boolean finalizacaminho(String vertice_entrada, String vertice_saida){
        boolean[] vertvisitado = new boolean[quantidadevertice];
        verificacaminho(nomevertice.get(vertice_saida).getindice(), vertvisitado);

        return vertvisitado[nomevertice.get(vertice_entrada).getindice()];
    }

    public void verificacaminho(int vertice_entrada,boolean[] vertice_visitado){
        int matriz[][] = mostraMatriz();
        if (vertice_visitado[vertice_entrada]){
            return;
        }else {
            vertice_visitado[vertice_entrada] = true;
        }
        for (int i =0; i<matriz[vertice_entrada].length; i++) {
            if (matriz[vertice_entrada][i] == 1){
                verificacaminho(i,vertice_visitado);
            }
        }
    }

    public List<String> verificatransitivodireto(String vertice) {
        mostraMatriz();
        boolean[] vertvisitado = new boolean[quantidadevertice];
        ArrayList<String> listaTransitivoDireto = new ArrayList<>();
        verificacaminho(nomevertice.get(vertice).getindice(),vertvisitado);

        for (int i=0; i<quantidadevertice; i++) {
            if(vertvisitado[i]){
                listaTransitivoDireto.add(listaVertice.get(i).getNome());
            }
        }
        return listaTransitivoDireto;
    }
    public List<String> verificatransitivoinverso(String vertice) {
        mostraMatriz();
        ArrayList<String> listaTransitivoInverso= new ArrayList<>();

        for (int i=0; i<quantidadevertice; i++) {
            if(finalizacaminho(listaVertice.get(i).getNome(),vertice)){
                listaTransitivoInverso.add(listaVertice.get(i).getNome());
            }
        }
        return listaTransitivoInverso;
    }

    public void exporta(String nome) throws IOException {
        File Grafoarqui = new File("C:/Users/PICHAU/Downloads/" + nome + ".dot"); // Correção no diretório e inclusão da extensão

        if (!Grafoarqui.exists()) {
            Grafoarqui.createNewFile();
            try (FileWriter fw = new FileWriter(Grafoarqui);
                 BufferedWriter bw = new BufferedWriter(fw)) {

                if (orientado) {
                    bw.write("digraph {");
                    bw.newLine();
                    for (Vertice v : listaVertice) {
                        if (v.getGrau() == 0) {
                            bw.write("  " + v.getNome() + " ;");
                            bw.newLine();
                        }
                    }
                    for (Aresta a : listaAresta) {
                        bw.write("  " + a.getVertice_entrada() + " -> " + a.getVertice_saida() + " [label=\"" + a.peso + "\"];");
                        bw.newLine();
                    }
                    bw.write(" }");
                } else {
                    bw.write("graph {");
                    bw.newLine();
                    for (Vertice v : listaVertice) {
                        if (v.getGrau() == 0) {
                            bw.write("  " + v.getNome() + " ;");
                            bw.newLine();
                        }
                    }
                    for (Aresta a : listaAresta) {
                        bw.write("  " + a.getVertice_entrada() + " -- " + a.getVertice_saida() + " [label=\"" + a.peso + "\"];");
                        bw.newLine();
                    }
                    bw.write(" }");
                }
            }
        }
    }

    public Grafo importa(String diretorio) throws IOException {
        Grafo g = new Grafo(true);
        diretorio = diretorio.replace("\\", "/");
        File Grafodir = new File(diretorio);

        try (FileReader fr = new FileReader(Grafodir);
             BufferedReader br = new BufferedReader(fr)) {

            String linha = br.readLine();

            if (!linha.contains("digraph")) {
                g = new Grafo(false);
                while (br.ready()) {
                    linha = br.readLine();
                    if (linha.contains("}")) {
                        return g;
                    }
                    if (!linha.contains("--")) {
                        linha = linha.replaceAll(";", " ");
                        g.addVertice(new Vertice(linha.trim()));
                    } else {
                        String[] array = linha.split("--");
                        array[0] = array[0].trim();
                        g.addVertice(new Vertice(array[0]));
                        array[1] = array[1].trim();
                        g.addVertice(new Vertice(array[1].charAt(0) + ""));

                        if (linha.contains("label")) {
                            char[] chars = linha.toCharArray();
                            String guarda = "";
                            for (char c : chars) {
                                if (Character.isDigit(c) || c == '.') {
                                    guarda = guarda + c;
                                }
                            }
                            float peso = Float.parseFloat(guarda);
                            g.addAresta(new Aresta(array[0], array[1].charAt(0) + "", peso));
                        } else {
                            double peso = 0;
                            g.addAresta(new Aresta(array[0], array[1].charAt(0) + "", peso));
                        }
                    }
                }

            } else {
                g = new Grafo(true);
                while (br.ready()) {
                    linha = br.readLine();
                    if (!linha.contains("->")) {
                        linha = linha.replaceAll(";", " ");
                        g.addVertice(new Vertice(linha.trim()));
                    } else {
                        String[] array = linha.split("->");
                        array[0] = array[0].trim();
                        g.addVertice(new Vertice(array[0]));
                        array[1] = array[1].trim();
                        g.addVertice(new Vertice(array[1].charAt(0) + ""));
                        if (linha.contains("label")) {
                            char[] chars = linha.toCharArray();
                            String guarda = "";
                            for (char c : chars) {
                                if (Character.isDigit(c) || c == '.') {
                                    guarda = guarda + c;
                                }
                            }
                            float peso = Float.parseFloat(guarda);
                            g.addAresta(new Aresta(array[0], array[1].charAt(0) + "", peso));
                        } else {
                            double peso = 0;
                            g.addAresta(new Aresta(array[0], array[1].charAt(0) + "", peso));
                        }
                    }
                }
            }
        }
        return g;
    }


    public void printDijkstra(String vertice){
        double[] lista = this.getDijkstra(vertice);
        for (int i = 0; i < this.quantidadevertice; i++){
            System.out.println(this.listaVertice.get(i).getNome() + " - " + lista[i]);
        }
    }

    public double[] getDijkstra(String vertice) {
        this.mostraMatriz();
        double[] listaDijkstra = new double[this.quantidadevertice];
        boolean[] vertice_visitado = new boolean[this.quantidadevertice];
        for (int i = 0; i < this.quantidadevertice; i++) {
            listaDijkstra[i] = Integer.MAX_VALUE;
        }
        listaDijkstra[nomevertice.get(vertice).getindice()] = 0;
        this.verificacaminho(nomevertice.get(vertice).getindice(), vertice_visitado, listaDijkstra);
        return listaDijkstra;
    }
    public void verificacaminho(int vertice_entrada, boolean[] vertice_visitado, double[] listaDijkstra){
        double minValor = Integer.MAX_VALUE;
        int minValorVertice = 0;

        if (vertice_visitado[vertice_entrada]){
            return;
        }
        else{
            vertice_visitado[vertice_entrada] = true;
        }

        for (int i = 0; i < this.quantidadevertice; i++){
            if (this.mostraMatriz()[vertice_entrada][i] >= 1){
                for (Aresta a: listaAresta) {
                    if (Objects.equals(a.getVertice_entrada() + a.getVertice_saida(), listaVertice.get(vertice_entrada).getNome() +
                            listaVertice.get(i).getNome())){
                        if (listaDijkstra[i] > a.peso + listaDijkstra[vertice_entrada]){
                            listaDijkstra[i] = a.peso + listaDijkstra[vertice_entrada];
                        }
                    }
                }
            }
            if (listaDijkstra[i] < minValor && !vertice_visitado[i]){
                minValor = listaDijkstra[i];
                minValorVertice = i;
            }
        }
        this.verificacaminho(minValorVertice, vertice_visitado, listaDijkstra);
    }
    public Set<Aresta> getArvoreGeradoraPrim(String verticeInicial) {
        Set<Aresta> arvore = new HashSet<>();
        Set<String> verticesVisitados = new HashSet<>();
        PriorityQueue<Aresta> filaPrioridade = new PriorityQueue<>((a1, a2) -> Double.compare(a1.peso, a2.peso));

        verticesVisitados.add(verticeInicial);
        for (Aresta aresta : listaAresta) {
            if (aresta.getVertice_entrada().equals(verticeInicial)) {
                filaPrioridade.add(aresta);
            }
        }

        while (!filaPrioridade.isEmpty()) {
            Aresta menorAresta = filaPrioridade.poll();

            String verticeSaida = menorAresta.getVertice_saida();

            if (!verticesVisitados.contains(verticeSaida)) {
                verticesVisitados.add(verticeSaida);
                arvore.add(menorAresta);

                for (Aresta aresta : listaAresta) {
                    if (aresta.getVertice_entrada().equals(verticeSaida) && !verticesVisitados.contains(aresta.getVertice_saida())) {
                        filaPrioridade.add(aresta);
                    }
                }
            }
        }

        return arvore;
    }
    public void reduzirGrafoMalgrange() {
        Map<String, Set<String>> conjuntoParaVertices = new HashMap<>();
        Map<String, Vertice> novoNomeParaVertice = new HashMap<>();

        for (Vertice v : listaVertice) {
            Set<String> conjunto = new HashSet<>();
            conjunto.add(v.getNome());
            conjuntoParaVertices.put(v.getNome(), conjunto);
            novoNomeParaVertice.put(v.getNome(), v);
        }

        List<Aresta> copiaArestas = new ArrayList<>(listaAresta);

        for (Aresta a : copiaArestas) {
            String nomeVerticeEntrada = a.getVertice_entrada();
            String nomeVerticeSaida = a.getVertice_saida();

            Set<String> conjuntoEntrada = conjuntoParaVertices.get(nomeVerticeEntrada);
            Set<String> conjuntoSaida = conjuntoParaVertices.get(nomeVerticeSaida);

            if (!conjuntoEntrada.equals(conjuntoSaida)) {

                Set<String> novoConjunto = new HashSet<>(conjuntoEntrada);
                novoConjunto.addAll(conjuntoSaida);


                for (String nome : novoConjunto) {
                    conjuntoParaVertices.put(nome, novoConjunto);
                }


                listaAresta.remove(a);
                listaAresta.add(new Aresta(novoConjunto.iterator().next(), novoConjunto.iterator().next(), 0.0));

                if (!orientado) {

                    listaAresta.add(new Aresta(novoConjunto.iterator().next(), nomeVerticeEntrada, 0.0));
                    listaAresta.add(new Aresta(nomeVerticeEntrada, novoConjunto.iterator().next(), 0.0));
                }
            }
        }

        listaVertice = new ArrayList<>(novoNomeParaVertice.values());
        nomevertice.clear();
        for (Vertice v : listaVertice) {
            nomevertice.put(v.getNome(), v);
        }
    }
}

