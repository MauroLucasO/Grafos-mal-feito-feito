package org.example;

import java.io.IOException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws IOException {
        Scanner criagrafo = new Scanner(System.in);
        Grafo g = null;

        int opcao;
        do {
            System.out.println("Menu Principal:");
            System.out.println("1. Criar Novo Grafo");
            System.out.println("2. Importar Grafo");
            System.out.println("3. Sair do Programa");
            System.out.print("Escolha uma opção: ");
            opcao = criagrafo.nextInt();

            switch (opcao) {
                case 1:
                    int subOpcao;
                    do {
                        System.out.println("Menu para criar um novo grafo:");
                        System.out.println("1. Grafo Orientado");
                        System.out.println("2. Grafo Não Orientado");
                        System.out.println("3. Voltar ao Menu Principal");
                        System.out.print("Escolha entre 1, 2 ou 3: ");
                        subOpcao = criagrafo.nextInt();

                        if (subOpcao == 1) {
                            g = criarNovoGrafo(criagrafo, true);
                            break;
                        } else if (subOpcao == 2) {
                            g = criarNovoGrafo(criagrafo, false);
                            break;
                        } else if (subOpcao == 3) {
                            break;
                        } else {
                            System.out.println("Opção inválida. Tente novamente.");
                        }
                    } while (true);
                    break;
                case 2:
                    System.out.print("Qual o caminho do arquivo:");
                    String caminho = criagrafo.next();
                    g = g.importa(caminho);
                    break;
                case 3:
                    System.out.println("Adeus!");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Opção inválida. Tente novamente.");
                    break;
            }

            if (g != null) {
                int escolha;
                do {
                    System.out.println("Menu de Operações no Grafo:");
                    System.out.println("1. Calcular Grau de Vértice");
                    System.out.println("2. Mostrar Ordem do Grafo");
                    System.out.println("3. Exportar Grafo");
                    System.out.println("4. Importar Grafo");
                    System.out.println("5. Verificar Transitividade Direta");
                    System.out.println("6. Verificar Transitividade Indireta");
                    System.out.println("7. Mostrar Matriz de Adjacência");
                    System.out.println("8. Executar Dijkstra");
                    System.out.println("9. Sair para o Menu Principal");
                    System.out.print("Escolha uma opção: ");
                    escolha = criagrafo.nextInt();

                    switch (escolha) {
                        case 1:
                            System.out.print("Escolha um vértice para calcular seu grau: ");
                            String grauvert = criagrafo.next();
                            System.out.println("O grau do vértice " + grauvert + " é: " + g.getGrauvertice(grauvert) + "\n");
                            break;
                        case 2:
                            System.out.println("A ordem do Grafo é: " + g.getOrdem());
                            break;
                        case 3:
                            System.out.print("Nome do arquivo: ");
                            String nome = criagrafo.next();
                            g.exporta(nome);
                            break;
                        case 4:
                            System.out.print("Qual o caminho do arquivo:");
                            String importCaminho = criagrafo.next();
                            g = g.importa(importCaminho);
                            break;
                        case 5:
                            System.out.print("Qual o vértice que deseja verificar transitividade direta? ");
                            String transitivodireto = criagrafo.next();
                            System.out.println("Transitividade Direta: \n" + g.verificatransitivodireto(transitivodireto));
                            break;
                        case 6:
                            System.out.print("Qual o vértice que deseja verificar transitividade indireta? ");
                            String transitivoindireto = criagrafo.next();
                            System.out.println("Transitividade Indireta: " + g.verificatransitivoindireto(transitivoindireto));
                            break;
                        case 7:
                            int[][] matrix = g.mostraMatriz();
                            for (int i = 0; i < g.getOrdem(); i++) {
                                for (int j = 0; j < g.getOrdem(); j++) {
                                    System.out.print(matrix[i][j] + " ");
                                }
                                System.out.println();
                            }
                            break;
                        case 8:
                            System.out.print("Qual vértice deseja iniciar o algoritmo de Dijkstra? ");
                            String verticeDijkstra = criagrafo.next();
                            g.printDijkstra(verticeDijkstra);
                            break;
                        case 9:
                            break;
                        default:
                            System.out.println("Opção inválida. Tente novamente.");
                            break;
                    }
                } while (escolha != 9);
            }
        } while (opcao != 3);
    }

    private static Grafo criarNovoGrafo(Scanner scanner, boolean orientado) {
        System.out.print("Quantos vértices são necessários?: ");
        int quantverti = scanner.nextInt();
        Grafo g = new Grafo(orientado);
        for (int i = 1; i <= quantverti; i++) {
            System.out.print("Qual o nome do " + i + "° vértice?: ");
            String nomevert = scanner.next();
            g.addVertice(new Vertice(nomevert));
        }
        System.out.print("Quantidade de arestas: ");
        int quantarest = scanner.nextInt();
        for (int i = 1; i <= quantarest; i++) {
            System.out.print("Qual o vértice de entrada da " + i + "° aresta?: ");
            String vertentrada = scanner.next();
            System.out.print("Qual o vértice de saída da " + i + "° aresta?: ");
            String vertsaida = scanner.next();
            System.out.print("Qual o peso da " + i + "° aresta?: ");
            double pesovar = scanner.nextDouble();
            g.addAresta(new Aresta(vertentrada, vertsaida, pesovar));
        }
        return g;
    }

}
