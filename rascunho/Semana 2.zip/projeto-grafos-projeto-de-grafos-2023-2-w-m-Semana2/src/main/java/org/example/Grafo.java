package org.example;

import java.io.*;
import java.util.*;

public class Grafo {

    private Map<String, Vertice> nomevertice;
    int quantidadevertice;
    boolean orientado;
    private ArrayList<Vertice> listaVertice;
    private ArrayList<Aresta> listaAresta;

    public Grafo(boolean orientado) {
        this.orientado = orientado;
        this.quantidadevertice = 0;
        this.listaAresta = new ArrayList<>();
        this.listaVertice = new ArrayList<>();
        this.nomevertice = new HashMap<>();
    }

    public void addAresta(Aresta a) {
        this.listaAresta.add(a);
        this.nomevertice.get(a.getVertice_entrada()).setGrau();
        this.nomevertice.get(a.getVertice_saida()).setGrau();
    }

    public void addVertice(Vertice v) {
        if (!nomevertice.containsKey(v.getNome())) {
            this.listaVertice.add(v);
            this.nomevertice.put(v.getNome(), v);
            this.quantidadevertice++;

        }
    }

    public int getOrdem() {
        return quantidadevertice;
    }

    public int getGrauvertice(String vertice) {
        return this.nomevertice.get(vertice).getGrau();
    }

    public static void menu() {
        System.out.println("Menu");
        System.out.println("\t 0. Sair");
        System.out.println("\t 1. Grau");
        System.out.println("\t 2. Ordem");
        System.out.println("\t 3. Exportar Grafo");
        System.out.println("\t 4. Importar Grafo");
        System.out.println("Opcao: ");
    }

    public void exporta(String nome) throws IOException {
        File Grafoarqui = new File("C:/Users/PICHAU/Documents/My Games/JOGOS/"+ nome + ".dot");

        if (!Grafoarqui.exists()) {
            Grafoarqui.createNewFile();
            FileWriter fw = new FileWriter(Grafoarqui, true);
            BufferedWriter bw = new BufferedWriter(fw);
            if (orientado) {
                bw.write("digraph {");
                bw.newLine();
                for (Vertice v : listaVertice) {
                    if (v.getGrau() == 0) {
                        bw.write("  " + v.getNome() + " ;");
                        bw.newLine();
                    }
                    ;
                }
                for (Aresta a : listaAresta) {
                    bw.write("  " + a.getVertice_entrada() + " ->1 " + a.getVertice_saida() + " [label=\"" + a.peso + "\"];");
                    bw.newLine();
                }
                bw.write(" }");
            } else {
                bw.write("graph {");
                bw.newLine();
                for (Vertice v : listaVertice) {
                    if (v.getGrau() == 0) {
                        bw.write("  " + v.getNome() + " ;");
                        bw.newLine();
                    }
                    ;
                }
                for (Aresta a : listaAresta) {
                    bw.write("  " + a.getVertice_entrada() + " -- " + a.getVertice_saida() + " [label=\"" + a.peso + "\"];");
                    bw.newLine();
                }
                bw.write(" }");


            }
            bw.close();
            fw.close();
        }
    }
    public Grafo importa(String diretorio) throws IOException {
        Grafo g = new Grafo(true);
        diretorio = diretorio.replaceAll("\\\\", "/");
        File Grafodir = new File(diretorio);
        FileReader fr = new FileReader(Grafodir);
        BufferedReader br = new BufferedReader(fr);
        String linha = br.readLine();
        if (!linha.contains("digraph")) {
            g = new Grafo(false);
            while (br.ready()) {
                linha = br.readLine();
                if (linha.contains("}")) {
                    return g;
                }
                if (!linha.contains("--")) {
                    linha = linha.replaceAll(";", " ");
                    g.addVertice(new Vertice(linha.trim()));

                } else {
                    String[] array = linha.split("--");
                    array[0] = array[0].trim();

                    g.addVertice(new Vertice(array[0]));
                    array[1] = array[1].trim();
                    g.addVertice(new Vertice(array[1].charAt(0) + ""));
                    if (linha.contains("label")) {
                        char[] chars = linha.toCharArray();
                        String guarda = "";
                        for (char c : chars) {
                            if (Character.isDigit(c) || c == '.') {
                                guarda = guarda + c;
                            }
                        }
                        float peso = Float.parseFloat(guarda);

                        g.addAresta(new Aresta(array[0], array[1].charAt(0) + "", peso));

                    } else {
                        double peso = 0;
                        g.addAresta(new Aresta(array[0], array[1].charAt(0) + "", peso));
                    }
                }
            }

        } else {
            g = new Grafo(true);
            while (br.ready()) {
                linha = br.readLine();
                if (!linha.contains("->")) {
                    linha = linha.replaceAll(";", " ");
                    g.addVertice(new Vertice(linha.trim()));
                } else {
                    String[] array = linha.split("->");
                    array[0] = array[0].trim();

                    g.addVertice(new Vertice(array[0]));
                    array[1] = array[1].trim();
                    g.addVertice(new Vertice(array[1].charAt(0) + ""));
                    if (linha.contains("label")) {
                        char[] chars = linha.toCharArray();
                        String guarda = "";
                        for (char c : chars) {
                            if (Character.isDigit(c) || c == '.') {
                                guarda = guarda + c;
                            }
                            float peso = Float.parseFloat(guarda);
                            ;
                            g.addAresta(new Aresta(array[0], array[1].charAt(0) + "", peso));
                        }
                    } else {
                        double peso = 0;
                        g.addAresta(new Aresta(array[0], array[1].charAt(0) + "", peso));
                    }

                }

            }
        }
        return g;
    }

}

