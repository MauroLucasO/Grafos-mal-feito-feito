package org.example;

public class Vertice {
    String nome;
    int grau;
    public Vertice(String nome) {
        this.nome = nome;
        this.grau = 0;
    }


    public int getGrau() {
        return grau;
    }

    public void setGrau(){
        this.grau++;
    }
    public String getNome() {
        return nome;
    }
}
