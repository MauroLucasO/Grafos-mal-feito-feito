package org.example;

import java.io.IOException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws IOException {

        Scanner criagrafo = new Scanner(System.in);
        System.out.print("Digite 1 para criar um novo grafo: ");
        int valor = criagrafo.nextInt();
        if (valor == 1) {
        } else {
            System.out.print("Adeus! ");
            System.exit(1406);
        }

        System.out.print("Digite 0 para o grafo não orientado ou 1 para orientado: ");
        int orientInt = criagrafo.nextInt();
        boolean orient = (orientInt == 1);

        System.out.print("Quantos vertices são necessarios ?:");
        int quantverti = criagrafo.nextInt();


        Grafo g = new Grafo(orient);

        for (int i = 1; i <= quantverti; i++) {

            System.out.print("Qual o nome do " + i + "° vertice?:");
            String nomevert = criagrafo.next();

            g.addVertice(new Vertice(nomevert));
        }
        System.out.print("Quantidade de arestas:");

        int quantarest = criagrafo.nextInt();

        for (int i = 1; i <= quantarest; i++) {
            System.out.print("Qual o vertice de entrada da " + i + "° aresta?:");
            String vertentrada = criagrafo.next();

            System.out.print("Qual o vertice de saída da " + i + "° aresta?:");
            String vertsaida = criagrafo.next();

            System.out.print("Qual o peso da " + i + "° aresta?:");
            double pesovar = criagrafo.nextDouble();
            g.addAresta(new Aresta(vertentrada, vertsaida, pesovar));

        }
        int opcao;
        do {
            g.menu();
            opcao = criagrafo.nextInt();

            switch (opcao) {
                case 1 -> {
                    System.out.print("Escolha um vertice para dizermos seu grau: ");
                    String grauvert = criagrafo.next();
                    System.out.println("O grau do vertice " + grauvert + " é: " + g.getGrauvertice(grauvert) + "\n");
                }
                case 2 -> {
                    System.out.println("A ordem do Grafo é: " + g.getOrdem());
                }
                case 3 -> {
                    System.out.print("Nome do arquivo: ");
                    String nome = criagrafo.next();
                    g.exporta(nome);
                }
                case 4 -> {
                    System.out.print("Qual o caminho do arquivo:");
                    String caminho = criagrafo.next();
                    g = g.importa(caminho);
                }
                  default -> System.exit(1406);
            }

        }while (opcao != 0);

    }


}
