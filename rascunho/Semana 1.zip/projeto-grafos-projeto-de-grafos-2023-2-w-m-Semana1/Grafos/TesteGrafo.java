package Grafos;
import java.util.Scanner;

public class TesteGrafo {
    public static void main(String[] args) {
        Grafo grafo = null;
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Menu:");
            System.out.println("\n1.Criar grafo");
            System.out.println("2.Verificar se existe grafo");
            System.out.println("3.Sair");

            System.out.print("\nEscolha uma opção: ");
            int escolha = scanner.nextInt();
            scanner.nextLine();

            if (escolha == 1) {
                grafo = new Grafo();
                System.out.println("Grafo criado.");
                criarGrafo(grafo, scanner);
            } else if (escolha == 2) {
                if (grafo == null) {
                    System.out.println("Nenhum grafo foi criado.");
                } else {
                    verificarGrafo(grafo, scanner);
                }
            } else if (escolha == 3) {
                scanner.close();
                System.exit(0);
            } else {
                System.out.println("Opção inválida.Tente novamente.");
            }
        }
    }
    private static void criarGrafo(Grafo grafo, Scanner scanner) {
        while (true) {
            System.out.println("\nMenu de Criação de Grafo:");
            System.out.println("\n1. Adicionar vértice");
            System.out.println("2. Adicionar aresta");
            System.out.println("3. Mostrar grafo");
            System.out.println("4. Voltar ao menu principal");

            System.out.print("\nEscolha uma opção: ");
            int opcaoGrafo = scanner.nextInt();
            scanner.nextLine();

            if (opcaoGrafo == 1) {
                System.out.print("Digite o nome do vértice: ");
                String vertice = scanner.nextLine();
                grafo.adicionarVertice(vertice);
            } else if (opcaoGrafo == 2) {
                System.out.print("Digite o primeiro vértice: ");
                String vertice1 = scanner.nextLine();
                System.out.print("Digite o segundo vértice: ");
                String vertice2 = scanner.nextLine();
                grafo.adicionarAresta(vertice1, vertice2);
            } else if (opcaoGrafo == 3) {
                grafo.mostrarGrafo();
            } else if (opcaoGrafo == 4) {
                return;
            } else {
                System.out.println("Opção inválida.Tente novamente.");
            }
        }
    }

    private static void verificarGrafo(Grafo grafo, Scanner scanner) {
        while (true) {
            System.out.println("\nMenu de Verificação do Grafo:");
            System.out.println("1. Verificar ordem do grafo");
            System.out.println("2. Verificar grau de um vértice");
            System.out.println("3. Voltar ao menu principal");

            System.out.print("Escolha uma opção: ");
            int opcaoVerificacao = scanner.nextInt();
            scanner.nextLine();

            if (opcaoVerificacao == 1) {
                int ordem = grafo.verificarOrdem();
                System.out.println("A ordem do grafo é " + ordem);

            } else if (opcaoVerificacao == 2) {

                System.out.print("Digite o vértice para verificar o grau: ");

                String vertice = scanner.nextLine();

                int grau = grafo.verificarGrauVertice(vertice);

                if (grau >= 0) {

                    System.out.println("O grau do vértice " + vertice + " é " + grau);
                } else {
                    System.out.println("Vértice não encontrado.");
                }
            } else if (opcaoVerificacao == 3) {
                return;
            } else {
                System.out.println("Opção inválida.Tente novamente.");
            }
        }
    }

}
