package Grafos;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Grafo {
    private List<String>vertices;
    private List<String[]>arestas;

    public Grafo() {
        this.vertices = new ArrayList<>();
        this.arestas = new ArrayList<>();
    }

    public void adicionarVertice(String vertice) {
        vertices.add(vertice);
    }

    public void adicionarAresta(String vertice1, String vertice2) {
        arestas.add(new String[]{vertice1, vertice2});
    }

    public void mostrarGrafo() {
        for (String vertice : vertices) {
            System.out.print(vertice + ": ");
            for (String[] aresta : arestas) {
                if (aresta[0].equals(vertice)) {
                    System.out.print(aresta[1] + " ");
                } else if (aresta[1].equals(vertice)) {
                    System.out.print(aresta[0] + " ");
                }
            }
            System.out.println();
        }
    }

    public int verificarOrdem() {
        return vertices.size();
    }

    public int verificarGrauVertice(String vertice) {
        int grau = 0;
        for (String[] aresta : arestas) {
            if (aresta[0].equals(vertice) || aresta[1].equals(vertice)) {
                grau++;
            }
        }
        return grau;
    }
}




